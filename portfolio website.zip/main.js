/* ===== EDIT YOUR DETAILS HERE (no need to touch index.html) ===== */
const CONFIG = {
  email: "",          // e.g. "you@example.com"
  linkedin: "",       // full LinkedIn profile URL
  github: "",         // full GitHub profile URL
  graduationYear: "", // add only when verified
  FORM_ENDPOINT: "",  // Formspree / Web3Forms URL. Empty = demonstration form
  astraDetails: "",   // accurate details about your Astra coordinator role
  stats: [["B.E.", "Computer Science"], ["2", "Certifications"], ["4", "Projects planned"]], // keep truthful
  services: [
    ["Basic Website Development","Simple personal websites and landing pages using HTML and CSS.",["Responsive pages","Clean, readable code","Hand-off notes"]],
    ["Website Updates","Basic layout, styling and content changes to an existing site.",["Updated pages","Change summary"]],
    ["Technical Documentation","Clear technical notes, setup guides and project documentation.",["Step-by-step guide","README or notes"]],
    ["Basic Linux and Git Assistance","Beginner-level command-line and version-control support.",["Command cheat sheet","Guided Git setup"]],
    ["Simple Deployment Assistance","Suitable beginner projects, using only tools I can demonstrate confidently.",["Deployed site","Deployment steps"]]
  ],
  projects: [ // leave github/demo empty to show "Coming Soon"
    {title:"Predictive Intelligent Climatology Analyzer and Information System for Airport Meteorological Center",category:"Academic Project",status:"Academic",
     desc:"An academic project focused on airport meteorological information, weather monitoring, and information support for aviation operations.",tags:["Add verified technologies"],github:"",demo:""},
    {title:"Responsive Personal Portfolio Website",category:"Practice Project",status:"This site",
     desc:"A responsive personal website demonstrating layout design, HTML, CSS, and web development fundamentals.",tags:["HTML","CSS","JavaScript"],github:"",demo:""},
    {title:"Linux and Git Practice Toolkit",category:"Learning Project",status:"Planned",
     desc:"A documented collection of useful Linux commands, Git workflows, and practical exercises.",tags:["Linux","Git"],github:"",demo:""},
    {title:"Docker-Based Sample Application",category:"Practice Project",status:"In Progress",
     desc:"A small sample application demonstrating containerization and basic deployment concepts.",tags:["Docker"],github:"",demo:""}
  ],
  certs: [ // add link and date when you have them
    {name:"Full-Stack Developer Designing",by:"Infosys Springboard",date:"",link:""},
    {name:"UI/UX Designing course",by:"ICT Academy",date:"",link:""}
  ]
};
/* ================================================================= */
const $=s=>document.querySelector(s), esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
$("#year").textContent=new Date().getFullYear();
$("#stats").innerHTML=CONFIG.stats.map(s=>`<div>${esc(s[0])}<small>${esc(s[1])}</small></div>`).join("");
$("#grad").textContent=CONFIG.graduationYear?"Graduated: "+CONFIG.graduationYear:"Graduation year: add year";
$("#astra").textContent=CONFIG.astraDetails||"Helped coordinate college events, building skills in coordination, communication and teamwork. (Replace with your accurate details in js/main.js.)";
$("#services-grid").innerHTML=CONFIG.services.map(s=>`<article class="card"><h3>${esc(s[0])}</h3><p>${esc(s[1])}</p><ul>${s[2].map(d=>`<li>${esc(d)}</li>`).join("")}</ul><div class="row"><a class="btn" href="#contact">Discuss a Project</a></div></article>`).join("");
const btn=(label,url)=>url?`<a class="btn" href="${esc(url)}" target="_blank" rel="noopener">${label}</a>`:`<span class="btn" aria-disabled="true">${label}: Coming Soon</span>`;
$("#projects-grid").innerHTML=CONFIG.projects.map((p,i)=>`<article class="card"><div class="thumb" aria-hidden="true">${esc(p.category)}</div><div><span class="tag">${esc(p.category)}</span><span class="tag">${esc(p.status)}</span></div><h3>${esc(p.title)}</h3><p>${esc(p.desc)}</p><ul class="chips">${p.tags.map(t=>`<li>${esc(t)}</li>`).join("")}</ul><div class="row"><button class="btn" data-i="${i}">View Details</button>${btn("GitHub Repository",p.github)}${btn("Live Demo",p.demo)}</div></article>`).join("");
$("#certs-grid").innerHTML=CONFIG.certs.map(c=>`<article class="card"><h3>${esc(c.by)}</h3><p>${esc(c.name)}</p><p class="note">Completed: ${esc(c.date||"add date")}</p><div class="row">${btn("Certificate",c.link)}</div></article>`).join("");
const L=[["Email",CONFIG.email,CONFIG.email&&"mailto:"+CONFIG.email],["LinkedIn",CONFIG.linkedin,CONFIG.linkedin],["GitHub",CONFIG.github,CONFIG.github]];
$("#contact-links").innerHTML=L.map(([n,v,h])=>h?`<li>${n}: <a href="${esc(h)}" target="_blank" rel="noopener">${esc(v)}</a></li>`:`<li class="off">${n}: add in js/main.js</li>`).join("");
$("#foot-links").innerHTML=L.slice(1).filter(l=>l[1]).map(l=>`<a href="${esc(l[1])}" target="_blank" rel="noopener">${l[0]}</a>`).join(" ");
// theme + mobile menu
const root=document.documentElement;
$("#theme").onclick=()=>{const t=root.dataset.theme==="dark"?"light":"dark";root.dataset.theme=t;try{localStorage.setItem("theme",t)}catch(e){}};
const menu=$("#menu"),nav=$("#nav");
const closeMenu=()=>{nav.classList.remove("open");menu.setAttribute("aria-expanded","false")};
menu.onclick=()=>{menu.setAttribute("aria-expanded",nav.classList.toggle("open"))};
nav.addEventListener("click",e=>{if(e.target.tagName==="A")closeMenu()});
// project modal
const modal=$("#modal");let opener;
document.addEventListener("click",e=>{const b=e.target.closest("[data-i]");if(!b)return;opener=b;const p=CONFIG.projects[b.dataset.i];
 $("#m-title").textContent=p.title;$("#m-body").innerHTML=`<p><span class="tag">${esc(p.category)}</span><span class="tag">${esc(p.status)}</span></p><p>${esc(p.desc)}</p><p class="note">Technologies: ${p.tags.map(esc).join(", ")}</p>`;modal.hidden=false;$("#m-close").focus()});
const closeModal=()=>{modal.hidden=true;opener&&opener.focus()};
$("#m-close").onclick=closeModal;modal.onclick=e=>{if(e.target===modal)closeModal()};
document.addEventListener("keydown",e=>{if(e.key==="Escape"){if(!modal.hidden)closeModal();closeMenu()}});
// active nav link
const links=[...nav.querySelectorAll("a")];
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)links.forEach(a=>a.classList.toggle("on",a.getAttribute("href")==="#"+e.target.id))}),{rootMargin:"-45% 0px -50% 0px"});
document.querySelectorAll("main section").forEach(s=>io.observe(s));
// resume: friendly message if the PDF is missing
fetch($("#resume").href,{method:"HEAD"}).then(r=>{if(!r.ok)throw 0}).catch(()=>{$("#resume").addEventListener("click",e=>{e.preventDefault();$("#resume-msg").textContent="Resume coming soon. Please use the contact form in the meantime."})});
// contact form
const f=$("#form"),st=$("#status");
f.addEventListener("submit",async e=>{e.preventDefault();let ok=true;
 [["name","Enter your name."],["email","Enter a valid email address."],["type","Choose a project type."],["msg","Describe your project."]].forEach(([id,m])=>{const el=$("#"+id),bad=!el.checkValidity();$("#e-"+id).textContent=bad?m:"";el.setAttribute("aria-invalid",bad);if(bad)ok=false});
 if(!ok){st.textContent="Please fix the highlighted fields.";return}
 if(!CONFIG.FORM_ENDPOINT){st.textContent="This is a demonstration form until configured. Your message was not sent.";return}
 try{const r=await fetch(CONFIG.FORM_ENDPOINT,{method:"POST",headers:{Accept:"application/json"},body:new FormData(f)});if(!r.ok)throw 0;st.textContent="Message sent. Thank you, I'll reply soon.";f.reset()}catch{st.textContent="Message could not be sent. Please try again or use the email address above."}});
