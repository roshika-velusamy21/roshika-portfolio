# Roshika Velusamy – Portfolio
Plain HTML, CSS and JavaScript. No build step, no paid services.

## Structure
`index.html` · `css/styles.css` · `js/main.js` (all your details live in `CONFIG` at the top) · `assets/images/profile.jpg` (your photo) · `assets/resume/Roshika_Velusamy_Resume.pdf` (your resume)

## Run locally
Open `index.html` in a browser, or use VS Code Live Server, or run `python -m http.server` in this folder and visit http://localhost:8000.

## Edit your content
Open `js/main.js` and fill in `CONFIG`: email, LinkedIn, GitHub, graduation year, certificate dates and links, Astra details, project technologies and links. Empty links automatically show "Coming Soon". Add your photo as `assets/images/profile.jpg` and your resume to `assets/resume/`.

## Contact form
Create a free form at formspree.io or web3forms.com, then paste its URL into `FORM_ENDPOINT`. Until then the form clearly says it is a demonstration.

## Publish free on GitHub Pages
1. Create a public repo named `roshika-portfolio`.
2. Push these files to the `main` branch.
3. Repo **Settings → Pages → Deploy from a branch → main / (root) → Save**.
4. Your site appears at `https://<your-username>.github.io/roshika-portfolio/` (name the repo `<username>.github.io` for a shorter URL).

## Before sharing on LinkedIn
- [ ] Photo added  - [ ] Resume added  - [ ] Email, LinkedIn, GitHub set
- [ ] Graduation year and certificate dates/links verified
- [ ] Project 1 technologies verified; Astra details added
- [ ] Contact form endpoint configured and tested
- [ ] Only mark projects complete once the repo and demo exist
